#include <optional>

std::optional func() {
    return {};
}

int main() {
    return 0;
}
