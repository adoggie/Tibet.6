#include <string_view>

std::string_view func() {
    return {};
}

int main() {
    return 0;
}
